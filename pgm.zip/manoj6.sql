set serveroutput on
declare
var1 number;
var2 number;
var3 number;
begin
var1:= &var1;
var2:= &var2;
var3 := var1+var2;
dbms_output.put_line('the sum of numbers is'||var3);
end;
/
