			-- procedure 

q)Declare a procedure to increase the salary of an employee by 2000
 by specifying the employee name.


sql> create or replace procedure sal_hike(ename in employee.employee_name % 
type,increase in employee.salary % type) as

sal employee.salary % type;
new_sal employee.salary % type;

begin
select salary into sal from employee where employee_name = ename;
new_sal := sal+ increase;
update employee set salary = new_sal where employee_name = ename;
dbms_output.put_line('table updated with new salary'||new_sal);
end;
/

sql> exec sal_hike('jack', 2000);


sql> select * from employee;
