set serveroutput on
declare
i number :=1;
fact number :=1;
n number := 5;
begin
while(i <= 5) loop
fact:= fact * i;
i:= i+1;
end loop;
dbms_output.put_line('factorial of'||n||'is'||fact);
end;
/
