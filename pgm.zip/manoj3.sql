set serveroutput on
declare
n1 number := 25;
n2 number := 10;
begin
if n1 > n2 then
dbms_output.put_line('number'||n1||'is greater than the number'||n2);
else
dbms_output.put_line('number'||n2||'is greater than the number'||n1);
end if;
end;
/
