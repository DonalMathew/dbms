set serveroutput on
declare
str varchar2(20);
begin
str:=rtrim('bangalore','res');
dbms_output.put_line(str);
end;
/
