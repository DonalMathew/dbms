                          -- procedure 

sql> create or replace procedure add1
(num1 in number, num2 in number, res out number) as
 
begin
 res := num1 + num2;
 end;
/

sql> set serveroutput on
declare
c number;
begin
add1(20,30,c);
dbms_output.put_line('sum is'||c);
end;
/
