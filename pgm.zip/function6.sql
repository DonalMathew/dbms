                         -- function

sql> create function mul(num1 number,num2 number) return number as
begin
return(num1*num2);
end;
/

sql> set serveroutput on
declare
result number;
begin
result := mul(10,20);
dbms_output.put_line('product is'||result);
end;
/
