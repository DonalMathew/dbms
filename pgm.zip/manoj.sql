set serveroutput on
declare
n1 number;
n2 number;
s number;
begin
n1:=10;
n2:=20;
s:=n1+n2;
dbms_output.put_line('sum of 10 and 20 is'||s);
end;
/
