set serveroutput on
declare
d1 date;
begin
d1:=sysdate;
dbms_output.put_line(d1);
end;
/
