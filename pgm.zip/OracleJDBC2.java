import java.awt.*;
import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;


class FormData
{
	public static void main(String[] args)
	{
		Frame f=new Frame();
		Label lbl1=new Label("First Name: ");
		Label lbl2=new Label("Last Name: ");
		Label lbl3=new Label("Email: ");
		Label lbl4=new Label("Address: ");	
		Label lbl5=new Label("Contact no: ");
		final TextField txt1=new TextField(20);
		final TextField txt2=new TextField(20);
		final TextField txt3=new TextField(20);
		final TextField txt4=new TextField(20);
		final TextField txt5=new TextField(20);
		Button b=new Button("Save");
		b.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				String v1=txt1.getText();
				String v2=txt2.getText();
				String v3=txt3.getText();
				String v4=txt4.getText();
				String v5=txt5.getText();
				try
				{
					Connection connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:ORCL","cs1","welcome");
					Statement stmt=connection.createStatement();
					int i=stmt.executeUpdate("insert into student(first_name,last_name,email,address,contact) values('"+v1+"','"+v2+"','"+v3+"','"+v4+"','"+v5+"')");
					JOptionPane.showMessageDialog(null,"Data inserted Successfully");
				}	
				catch(Exception ex)
				{
					System.out.println("error");
				}
			}
		});
		Panel p=new Panel(new GridLayout(6,2));
		p.add(lbl1);
		p.add(txt1);
		p.add(lbl2);
		p.add(txt2);
		p.add(lbl3);
		p.add(txt3);
		p.add(lbl4);
		p.add(txt4);
		p.add(lbl5);
		p.add(txt5);
		p.add(b);
		f.add(p);
		f.setVisible(true);
		f.pack();
	}
}