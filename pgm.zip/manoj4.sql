set serveroutput on
declare
i number;
fact number:=1;
begin
for i in 1..5 loop
fact:=fact * i;
end loop;
dbms_output.put_line('factorial is'||fact);
end;
/
