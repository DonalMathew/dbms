				-- user defined exceptions 

q) declare a user defined exception to raise an exception 
if the salary is less than 15000 
and give a message 'salary is very low' otherwise display the salary for
the given employee.

set serveroutput on
declare
	low_sal exception;
	sal employee.salary % type;
	ename employee.employee_name % type := '&ename';
begin
   select employee.salary into sal from employee where employee_name = ename;
   if sal < 15000 then
   raise low_sal;
   else
   dbms_output.put_line('salary is'||sal);
   end if;
exception
	when low_sal then
	dbms_output.put_line('salary is very low!!! select another record!!!');
end;
/

sql> enter value for ename = jack;