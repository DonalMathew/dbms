Q) Write a pl/sql cursor to print employee no and employee name of 
first ten employees from the employees table    

set serveroutput on
declare
v_empno employees.employee_id % type;
v_ename employees.last_name % type;
cursor emp_cursor is select employee_id, last_name from employees;
begin
open emp_cursor;
for i in 1..10 loop
fetch emp_cursor into v_empno, v_ename;
dbms_output.put_line(v_empno||'-'||v_ename);
end loop;
close emp_cursor;
end;
/
