				
q)function to return salary of an employee from employee table

sql> create or replace function get_salary
(employeename in employee.employee_name%type) return employee.salary%type as

newsal employee.salary%type;
begin
select salary into newsal from employee where 
employee.employee_name=employeename;
return(newsal);
end;
/

sql> select get_salary(employee_name) from employee where employee_name ='jack';