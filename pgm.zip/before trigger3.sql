            				-- before trigger 

Q) create trigger for item table in which insertion of 
new row should not be permitted on sundays.

set serveroutput on
create or replace trigger emp_trig before insert on item for each row
declare
dd varchar2 (25);
begin
dd:=to_char (sysdate,'day');
if rtrim (upper(dd))=upper ('sunday') then
raise_application_error (-20888,'you cannot insert new row on sunday');
end if;
end;
/
