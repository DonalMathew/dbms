set serveroutput on
DECLARE
  // v_fname CHAR(25);
  V_fname employees.first_name%TYPE;
BEGIN
  SELECT first_name INTO v_fname
  FROM employees WHERE employee_id=200;
  DBMS_OUTPUT.PUT_LINE(' First Name is : '||v_fname);
END;
/