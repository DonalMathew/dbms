                               		--package 

q) create a package called item_mgt. include a procedure to update price of 
item whose code is given. execute the procedure within the package.

sql> create or replace package item_mgt as

procedure upitem(itno in number);

end item_mgt;
/

sql> create or replace package body item_mgt as

procedure upitem(itno in number) is

begin
update item set price =price*10 where itemno=itno;
end upitem;

end item_mgt;
/

sql> exec item_mgt.upitem(2);

