q) plsql package for updating and deleting values in a table.

create or replace package pkg_student is 
procedure updaterecord(sno int);
function deleterecord(sno1 int ) return boolean;
end pkg_student;
/

create or replace package body pkg_student is

procedure updaterecord(sno int) is 
begin
update student set age=24 where rollno=sno;
if sql%found then
dbms_output.put_line('Record updated ');
else
dbms_output.put_line('Record not found');
end if;
end updaterecord;

function deleterecord(sno1 int) return boolean is 
begin
delete from student where rollno=sno1;
return sql%found;
end deleterecord;

end pkg_student;
/

set serveroutput on
begin
pkg_student.updaterecord(1);
if pkg_student.deleterecord(2) then
dbms_output.put_line('Record deleted');
else
dbms_output.put_line('Record not Deleted');
end if;
end;
/